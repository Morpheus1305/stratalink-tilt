import { Button } from "@/components/ui/button";
import { ArrowRight, FileText } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { DashboardData } from "@shared/schema";
import { BottomTicker } from "@/components/bottom-ticker";
import { getPoLiRating } from "@/lib/poli-rating";
import stratalinkLogo from "@assets/logo_stratalink_1764604924054.png";

// Always load BTC data on the hero page for consistent, populated metrics
const DEFAULT_HERO_TOKEN = "BTC";

export function LandingHero() {
  const { data: dashboardData, isLoading } = useQuery<DashboardData>({
    queryKey: ['/api/dashboard', DEFAULT_HERO_TOKEN],
    queryFn: async () => {
      const response = await fetch(`/api/dashboard?asset=${DEFAULT_HERO_TOKEN}`);
      if (!response.ok) {
        throw new Error('Failed to fetch dashboard data');
      }
      return response.json();
    },
    refetchInterval: 10000,
  });

  if (isLoading || !dashboardData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-primary text-sm font-mono">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border h-14 flex items-center px-6">
        <div className="flex items-center gap-3">
          <img 
            src={stratalinkLogo} 
            alt="StrataLink Labs" 
            className="w-10 h-10 rounded-full object-cover"
            style={{ 
              filter: 'brightness(0) invert(1)',
            }}
          />
          <span className="font-semibold text-sm tracking-tight">STRATALINK LABS LIQUIDITY INTELLIGENCE TERMINAL</span>
        </div>
        <nav className="ml-auto flex items-center gap-6">
          <Link href="/login" data-testid="link-platform">
            <span className="text-sm hover-elevate active-elevate-2 px-3 py-1.5 rounded-md cursor-pointer">
              PLATFORM
            </span>
          </Link>
          <span className="text-sm text-muted-foreground px-3 py-1.5 cursor-pointer">
            DEMO MODE
          </span>
          <Link href="/docs" data-testid="link-about">
            <span className="text-sm hover-elevate active-elevate-2 px-3 py-1.5 rounded-md cursor-pointer">
              ABOUT
            </span>
          </Link>
          <span className="text-sm hover-elevate active-elevate-2 px-3 py-1.5 rounded-md cursor-pointer">
            HELP
          </span>
        </nav>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-between px-12 gap-16">
        {/* Left Side - Hero Content */}
        <div className="flex-1 max-w-2xl">
          <div className="flex items-center gap-4 mb-8">
            <img 
              src={stratalinkLogo} 
              alt="StrataLink Labs" 
              className="w-16 h-16 rounded-full object-cover"
              style={{ 
                filter: 'brightness(0) invert(1)',
              }}
            />
            <div className="text-sm text-muted-foreground leading-tight">
              The Liquidity Truth Layer — powered by STRATA AI and PoLi.
            </div>
          </div>

          <h1 className="text-5xl font-bold leading-tight mb-6 text-primary tracking-tight">
            THE INSTITUTIONAL
            <br />
            LIQUIDITY TERMINAL
          </h1>

          <p className="text-lg text-foreground mb-4 leading-relaxed max-w-xl">
            Real-time Liquidity Risk Intelligence for digital assets.
            <br />
            Built for regulators, exchanges, protocols, and institutional risk managers.
          </p>

          <ul className="space-y-2 mb-8 text-sm">
            <li className="flex items-start gap-2">
              <span className="text-primary mt-0.5">•</span>
              <span>Comprehensive depth, spread & volatility analytics</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-0.5">•</span>
              <span>Real-time CEX/DEX ratio & concentration risk metrics</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-0.5">•</span>
              <span>Automated stress-signal detection & compliance reporting</span>
            </li>
          </ul>

          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button 
                size="lg" 
                className="font-semibold"
                data-testid="button-enter-platform"
              >
                ENTER PLATFORM
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link href="/docs">
              <Button 
                variant="outline" 
                size="lg"
                className="font-semibold"
                data-testid="button-documentation"
              >
                <FileText className="mr-2 h-4 w-4" />
                DOCUMENTATION
              </Button>
            </Link>
          </div>
        </div>

        {/* Right Side - Live Market Data */}
        <div className="flex-1 max-w-md">
          <div className="border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-primary">LIVE MARKET DATA</h3>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-chart-3 animate-pulse" />
                <span className="text-xs text-chart-3">LIVE</span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="py-2 border-b border-border">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-muted-foreground tracking-wide">POLI SCORE</span>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-2xl font-bold">{Math.round(dashboardData.liquidityScore.score)}</span>
                    <span className="text-xs text-muted-foreground">/100</span>
                    <span className={`text-xs ${dashboardData.liquidityScore.change24h >= 0 ? 'text-chart-3' : 'text-destructive'}`}>
                      {dashboardData.liquidityScore.change24h >= 0 ? '↗' : '↘'} {dashboardData.liquidityScore.change24h >= 0 ? '+' : ''}{dashboardData.liquidityScore.change24h.toFixed(1)}%
                    </span>
                  </div>
                </div>
                <div className="flex justify-end">
                  <span className="text-xs text-muted-foreground">
                    Liquidity Rating: <span className="font-bold text-foreground" data-testid="text-landing-poli-rating">{getPoLiRating(Math.round(dashboardData.liquidityScore.score))}</span>
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-border">
                <span className="text-xs text-muted-foreground tracking-wide">MARKET DEPTH</span>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xl font-bold text-accent">{dashboardData.liveMetrics.find(m => m.label === 'MARKET DEPTH')?.value || '$0M'}</span>
                  <span className={`text-xs ${(dashboardData.liveMetrics.find(m => m.label === 'MARKET DEPTH')?.change || 0) >= 0 ? 'text-chart-3' : 'text-destructive'}`}>
                    {(dashboardData.liveMetrics.find(m => m.label === 'MARKET DEPTH')?.change || 0) >= 0 ? '↗' : '↘'} {(dashboardData.liveMetrics.find(m => m.label === 'MARKET DEPTH')?.change || 0) >= 0 ? '+' : ''}{(dashboardData.liveMetrics.find(m => m.label === 'MARKET DEPTH')?.change || 0).toFixed(1)}%
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-border">
                <span className="text-xs text-muted-foreground tracking-wide">BID-ASK SPREAD</span>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xl font-bold text-accent">{dashboardData.liveMetrics.find(m => m.label === 'BID-ASK SPREAD')?.value || '0%'}</span>
                  <span className={`text-xs ${(dashboardData.liveMetrics.find(m => m.label === 'BID-ASK SPREAD')?.change || 0) >= 0 ? 'text-chart-3' : 'text-destructive'}`}>
                    {(dashboardData.liveMetrics.find(m => m.label === 'BID-ASK SPREAD')?.change || 0) >= 0 ? '↗' : '↘'} {(dashboardData.liveMetrics.find(m => m.label === 'BID-ASK SPREAD')?.change || 0) >= 0 ? '+' : ''}{(dashboardData.liveMetrics.find(m => m.label === 'BID-ASK SPREAD')?.change || 0).toFixed(1)}%
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-border">
                <span className="text-xs text-muted-foreground tracking-wide">VOLATILITY 24H</span>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xl font-bold text-destructive">{dashboardData.liveMetrics.find(m => m.label === 'VOLATILITY 24H')?.value || '0%'}</span>
                  <span className={`text-xs ${(dashboardData.liveMetrics.find(m => m.label === 'VOLATILITY 24H')?.change || 0) >= 0 ? 'text-chart-3' : 'text-destructive'}`}>
                    {(dashboardData.liveMetrics.find(m => m.label === 'VOLATILITY 24H')?.change || 0) >= 0 ? '↗' : '↘'} {(dashboardData.liveMetrics.find(m => m.label === 'VOLATILITY 24H')?.change || 0) >= 0 ? '+' : ''}{(dashboardData.liveMetrics.find(m => m.label === 'VOLATILITY 24H')?.change || 0).toFixed(1)}%
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between py-2">
                <span className="text-xs text-muted-foreground tracking-wide">CEX/DEX RATIO</span>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xl font-bold">{dashboardData.liveMetrics.find(m => m.label === 'CEX/DEX RATIO')?.value || '0:0'}</span>
                  <span className={`text-xs ${(dashboardData.liveMetrics.find(m => m.label === 'CEX/DEX RATIO')?.change || 0) >= 0 ? 'text-chart-3' : 'text-destructive'}`}>
                    {(dashboardData.liveMetrics.find(m => m.label === 'CEX/DEX RATIO')?.change || 0) >= 0 ? '↗' : '↘'} {(dashboardData.liveMetrics.find(m => m.label === 'CEX/DEX RATIO')?.change || 0) >= 0 ? '+' : ''}{(dashboardData.liveMetrics.find(m => m.label === 'CEX/DEX RATIO')?.change || 0).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Ticker - Dynamic */}
      <BottomTicker items={dashboardData.tickerItems} />
    </div>
  );
}
