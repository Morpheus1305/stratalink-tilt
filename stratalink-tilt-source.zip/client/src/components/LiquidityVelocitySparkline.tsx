import { useMemo } from "react";
import { useMicroFeed } from "@/contexts/MicrostructureFeed";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  Area,
  ReferenceLine,
  CartesianGrid,
  Tooltip,
  XAxis,
  YAxis,
  BarChart,
  Bar,
} from "recharts";

type Point = { v: number; t: number };

type VelocityPoint = { i: number; v: number };
type DepthChangePoint = { i: number; dv: number };
type ReplayPoint = { i: number; pulse: number };

/**
 * VELOCITY (Δdepth / Δtime → $M/min)
 */
function buildVelocitySeries(depthSeries: Point[]): VelocityPoint[] {
  if (!depthSeries || depthSeries.length < 2) return [];
  const out: VelocityPoint[] = [];

  for (let i = 1; i < depthSeries.length; i++) {
    const prev = depthSeries[i - 1];
    const curr = depthSeries[i];
    const dt = (curr.t - prev.t) / 60000;
    if (dt <= 0) continue;
    const dv = curr.v - prev.v;
    out.push({ i, v: dv / dt / 1_000_000 });
  }

  if (out.length === 1) out.push({ i: out[0].i + 1, v: out[0].v });

  return out;
}

/**
 * DEPTH CHANGE (absolute Δdepth → USD)
 */
function buildDepthChangeSeries(depthSeries: Point[]): DepthChangePoint[] {
  if (!depthSeries || depthSeries.length < 2) return [];
  const out: DepthChangePoint[] = [];

  for (let i = 1; i < depthSeries.length; i++) {
    const prev = depthSeries[i - 1];
    const curr = depthSeries[i];
    const dv = curr.v - prev.v;
    out.push({ i, dv });
  }

  if (out.length === 1) out.push({ i: out[0].i + 1, dv: out[0].dv });

  return out;
}

/**
 * MICROSTRUCTURE REPLAY (event overlay)
 * Convert depth pulses into bars (red = outflow, green = inflow)
 */
function buildReplaySeries(depthSeries: Point[]): ReplayPoint[] {
  if (!depthSeries || depthSeries.length < 2) return [];
  return depthSeries.slice(1).map((p, i) => ({
    i: i + 1,
    pulse: p.v - depthSeries[i].v,
  }));
}

export default function LiquidityVelocitySparkline() {
  const { depthSeries, stale } = useMicroFeed();

  const velocity = useMemo(
    () => buildVelocitySeries(depthSeries),
    [depthSeries]
  );

  const depthChange = useMemo(
    () => buildDepthChangeSeries(depthSeries),
    [depthSeries]
  );

  const replay = useMemo(
    () => buildReplaySeries(depthSeries),
    [depthSeries]
  );

  const latestVel =
    velocity.length > 0 ? velocity[velocity.length - 1].v : null;

  const velColor = latestVel == null
    ? "#8ea3c7"
    : latestVel >= 0
    ? "#23e07b"
    : "#ff5252";

  return (
    <div className="flex flex-col space-y-3">

      <div className="text-[10px] uppercase tracking-[0.16em] text-neutral-500">
        Liquidity Dynamics (Velocity + Depth Change)
      </div>

      <div className="text-xs" style={{ color: velColor }}>
        {latestVel == null
          ? stale
            ? "Stale / unavailable"
            : "Collecting…"
          : `${latestVel >= 0 ? "+" : ""}${latestVel.toFixed(2)}M/min`}
      </div>

      <div style={{ height: 80 }}>
        {velocity.length === 0 ? (
          <div className="text-[11px] text-neutral-500 h-full flex items-center">
            Waiting for depth movements…
          </div>
        ) : (
          <ResponsiveContainer>
            <LineChart data={velocity}>
              <defs>
                <linearGradient id="velArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2cc7ff" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#050814" stopOpacity={0} />
                </linearGradient>
              </defs>

              <CartesianGrid stroke="#242b3f" strokeDasharray="2 3" vertical={false} />
              <XAxis dataKey="i" hide />
              <YAxis 
                tick={{ fill: "#6d7da2", fontSize: 9 }}
                tickFormatter={(v: number) => `${v.toFixed(1)}M`} 
                axisLine={false} 
                tickLine={false} 
              />

              <ReferenceLine y={0} stroke="#444a63" strokeDasharray="3 2" />

              <Tooltip
                formatter={(value: number) => [`${value.toFixed(3)}M/min`, "Velocity"]}
                labelFormatter={() => ""}
                contentStyle={{
                  background: "#050814", 
                  border: "1px solid #1a2138",
                  borderRadius: 8, 
                  padding: "6px 8px", 
                  fontSize: 11, 
                  color: "#c3d0ea",
                }}
              />

              <Area type="monotone" dataKey="v" fill="url(#velArea)" stroke="none" />
              <Line type="monotone" dataKey="v" stroke="#2cc7ff" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="text-[10px] uppercase tracking-[0.16em] text-neutral-500">
        Depth Change (Δdepth per sample)
      </div>
      <div style={{ height: 70 }}>
        <ResponsiveContainer>
          <LineChart data={depthChange}>
            <Line
              type="monotone"
              dataKey="dv"
              stroke="#ffaa33"
              strokeWidth={2}
              dot={false}
              isAnimationActive={true}
            />
            <ReferenceLine y={0} stroke="#444a63" strokeDasharray="3 2" />
            <XAxis hide />
            <YAxis hide />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="text-[10px] uppercase tracking-[0.16em] text-neutral-500">
        Microstructure Replay (Depth Pulses)
      </div>

      <div style={{ height: 50 }}>
        <ResponsiveContainer>
          <BarChart data={replay}>
            <Bar
              dataKey="pulse"
              radius={[3, 3, 3, 3]}
              fill="#23e07b"
              isAnimationActive={true}
            />
            <ReferenceLine y={0} stroke="#444a63" />
            <XAxis hide />
            <YAxis hide />
          </BarChart>
        </ResponsiveContainer>
      </div>

    </div>
  );
}
