# StrataLink Labs — TILT Source Export Manifest
**Generated:** 2026-05-10  
**Version:** TILT v1.0 — Phase 1 Institutional Preview  
**Archive:** stratalink-tilt-source.zip  
**Files included:** 212 source files | ~1.5 MB uncompressed | ~475 KB compressed

---

## Main Entry Point

```
server/index-dev.ts       ← Node.js process entry (dev mode via tsx)
```
Single process: Express (backend) + Vite middleware (frontend) on **port 5000**

---

## Directory Structure & Module Descriptions

### `/client/src/` — React Frontend (TypeScript + Vite)

| Path | Description |
|------|-------------|
| `App.tsx` | Root router (Wouter). Registers all routes, auth guards, providers |
| `main.tsx` | React DOM entry point |
| `index.css` | Global design system: Bloomberg dark theme, CSS custom properties, Tailwind base |

#### `/client/src/pages/platform/`
| File | Description |
|------|-------------|
| `tilt-terminal.tsx` | **TILT Institutional Liquidity Terminal** — Bloomberg-style 4-panel grid. Polls `/api/analytics/l5f/snapshot/:symbol` every 5s. Asset switching BTC/ETH/SOL |
| `tilt-terminal.css` | Scoped CSS for TILT (all variables/classes prefixed `tilt-` to avoid conflicts) |
| `ccp-margin-unified.tsx` | CCP Margin Verification Console — clearing house risk officers view |
| `tape.tsx` | Liquidity Tape — real-time event stream viewer |

#### `/client/src/pages/regulatory/`
| File | Description |
|------|-------------|
| `RegulatoryAdgmView.tsx` | RCL — Regulatory Consumption Layer for ADGM. Read-only market integrity observatory |

#### `/client/src/pages/identity/`
| File | Description |
|------|-------------|
| `IdentityLandingPage.tsx` | Identity Intelligence overview (Arkham API integration) |
| `LiquidityFragmentationPage.tsx` | On-chain liquidity fragmentation analysis |
| `MMIntegrityPage.tsx` | Market maker integrity surveillance |
| `PoliPlusPage.tsx` | PoLi+ enhanced scoring with identity layer |
| `IdentityAlertsPage.tsx` | Identity-linked alert feed |
| `RegSurveillancePage.tsx` | Regulatory surveillance dashboard |

#### `/client/src/pages/analytics/`
| File | Description |
|------|-------------|
| `AnalyticsPage.tsx` | L5F Analytics overview page |

#### `/client/src/components/`
| File | Description |
|------|-------------|
| `platform-tabs.tsx` | Secondary navigation bar: OVERVIEW, CCP MARGIN, TRENDS, PORTFOLIO, ALERTS, SCORECARD, ANALYTICS, TAPE, RCL, TILT |
| `dashboard-header.tsx` | Global top navigation bar with live status indicator |
| `RequireAuth.tsx` | Auth gate HOC — redirects unauthenticated users to /login |
| `bottom-ticker.tsx` | Scrolling market data ticker (app-wide footer) |
| `date-time-bar.tsx` | UTC clock bar |
| `tsle-chart.tsx` | TSLE time-series chart component |
| `stress-signals-panel.tsx` | Stress indicator panel |
| `token-selector.tsx` | Dynamic token selection (CoinMarketCap Top 20) |

---

### `/server/` — Express Backend (TypeScript)

| File | Description |
|------|-------------|
| `index-dev.ts` | Dev server entry: mounts Express + Vite middleware on port 5000 |
| `routes.ts` | Root route registration — mounts all sub-routers |
| `storage.ts` | In-memory storage (MemStorage) implementing IStorage interface |
| `db.ts` | PostgreSQL connection via Neon serverless (alerts persistence) |
| `auth.ts` | JWT + OTP authentication middleware |

#### `/server/routes/` — API Route Handlers
| File | Description |
|------|-------------|
| `analytics-l5f.ts` | `GET /api/analytics/l5f/snapshot/:symbol` — L5F composite score endpoint (1s cache) |
| `lis.ts` | LIS ingest endpoint — records LISSnapshots into TSLE buffer |
| `okx-relay.ts` | OKX spot/perps depth + funding relay |
| `bybit-relay.ts` | Bybit relay (geo-blocked → CoinGecko synthetic fallback) |
| `dydx-relay.ts` | dYdX v4 CLOB perps depth + funding |
| `bitget-relay.ts` | Bitget spot/perps depth + funding |
| `gmx-relay.ts` | GMX v2 (Arbitrum) pool-based perps depth |
| `hyperliquid-relay.ts` | Hyperliquid L2 book perps depth + funding |
| `deribit-relay.ts` | Deribit spot/perps depth |
| `uniswap-relay.ts` | Uniswap V3 pool TVL-based depth |
| `curve-relay.ts` | Curve AMM pool depth (synthetic when unavailable) |
| `canton-relay.ts` | Canton Network on-chain attestation (PoLi L5 trust tier) |
| `otc-relay.ts` | OTC/RFQ bilateral dark liquidity (synthetic when unconfigured) |
| `depth.ts` | CEX depth aggregation endpoint |
| `funding.ts` | Funding rate endpoint (OKX primary) |
| `poli.ts` | PoLi scoring API |
| `poliApi.ts` | PoLi evidence API |
| `poliEvidence.ts` | PoLi evidence routes |
| `rcl.ts` | RCL regulatory API |
| `tape.ts` | Liquidity Tape event stream API |
| `alerts.ts` | Alert rules CRUD + trigger history |

#### `/server/services/` — Business Logic
| File | Description |
|------|-------------|
| `analytics-layer.ts` | **L5F 5-Factor Model** — computes DQ×0.30 + R×0.20 + F×0.15 + EI×0.20 + RS×0.15 across all 14 venues from TSLE buffer |
| `tsle-buffer.ts` | **TSLE Ring Buffer** — 360-point in-memory buffer (~1hr at 10s). Stores TSLEPoints + raw LISSnapshots. Core state for all analytics |
| `poliEngine.ts` | PoLi scoring engine (0–100, rated AAA–D) |
| `cexOrderbooks.ts` | CEX orderbook aggregation (Binance/Coinbase/Kraken) |
| `divergence-detector.ts` | Cross-venue price/depth divergence detection |
| `alert-service.ts` | Alert trigger evaluation (DIVERGENCE, REGIME_CHANGE, POLI_DROP, DEPTH_DROP) |
| `tapeStore.ts` | In-memory event ring buffer for Liquidity Tape |
| `depthAggregator.ts` | Multi-venue depth aggregation service |
| `executionIntelligence.ts` | Execution cost estimation |
| `rclMock.ts` | RCL synthetic data generator |
| `venueLiquidity.ts` | Per-venue liquidity state computation |

#### `/server/PoLi/`
| File | Description |
|------|-------------|
| `composePoLiFromTSLE.ts` | Composes full PoLi evidence object from TSLE state |

---

### `/shared/` — Shared Types (Frontend + Backend)
| File | Description |
|------|-------------|
| `schema.ts` | Drizzle ORM schema — alerts, alert_history, users tables |
| `poli.ts` | PoLi score types and rating band definitions (AAA–D) |
| `poliEvidence.ts` | PoLi evidence object structure |
| `liquidity-truth.ts` | LTS (Liquidity Truth System) unified types |
| `liquidityTape.ts` | Tape event types (DEPTH_UPDATE, TRADE, LIQUIDATION, FUNDING, SPREAD_CHANGE) |
| `venue-config.ts` | Venue metadata and classification |
| `venueSymbols.ts` | Per-venue supported symbols |
| `roles.ts` | User role definitions |

---

## Key Dependencies

### Runtime
| Package | Version | Purpose |
|---------|---------|---------|
| `express` | ^4.21.2 | HTTP server |
| `react` | ^18.3.1 | Frontend UI |
| `react-dom` | ^18.3.1 | React DOM renderer |
| `typescript` | 5.6.3 | Type system |
| `vite` | ^5.4.20 | Frontend build tool + dev server |
| `tsx` | ^4.20.5 | TypeScript execution for Node |
| `@tanstack/react-query` | ^5.60.5 | Server state management |
| `wouter` | ^3.3.5 | Client-side routing |
| `drizzle-orm` | ^0.39.1 | ORM (PostgreSQL alerts persistence) |
| `@neondatabase/serverless` | ^0.10.4 | Neon PostgreSQL serverless driver |
| `recharts` | ^2.15.2 | Financial data charts |
| `tailwindcss` | ^3.4.17 | Utility-first CSS |
| `axios` | ^1.13.2 | HTTP client for venue relay calls |
| `zod` | ^3.24.2 | Runtime schema validation |
| `lucide-react` | ^0.453.0 | Icon system |
| `jsonwebtoken` | ^9.0.2 | JWT auth tokens |
| `nodemailer` | ^7.0.10 | Email delivery (OTP) |
| `resend` | ^6.5.2 | Email API (alerts) |
| `jspdf` | ^4.0.0 | PDF export (RCL reports) |
| `node-cron` | ^4.2.1 | Scheduled ingestion jobs |

### UI Components
| Package | Version | Purpose |
|---------|---------|---------|
| `@radix-ui/*` | ^1–2.x | Headless accessible UI primitives (Shadcn) |
| `class-variance-authority` | ^0.7.1 | Component variant API |
| `framer-motion` | ^11.13.1 | Animations |
| `react-hook-form` | ^7.55.0 | Form state management |
| `date-fns` | ^3.6.0 | Date formatting |

---

## Environment Variables Required

```env
# Core
DATABASE_URL=postgresql://...          # Neon PostgreSQL (alerts persistence)
RELAY_SECRET=<secret>                  # Shared secret for relay endpoints (x-relay-secret header)
JWT_SECRET=<secret>                    # JWT signing key

# Email (for OTP auth and alerts)
RESEND_API_KEY=<key>                   # Resend email API

# Optional venue connectors (fall back to synthetic when unset)
CANTON_LEDGER_URL=                     # Canton Network ledger endpoint
OTC_RFQ_URL=                           # OTC/RFQ desk endpoint

# Optional external data
COINMARKETCAP_API_KEY=                 # CMC Top 20 token list
ARKHAM_API_KEY=                        # Arkham identity intelligence
```

---

## Architecture Notes for Deployment

1. **Single process**: Backend (Express) and frontend (Vite) run in one Node.js process in dev. For production, run `npm run build` to produce a static frontend bundle served by Express.

2. **In-memory state**: The TSLE buffer (ring buffer, 360 points) holds no persistent state. A process restart resets all L5F analytics. R and RS factors need ~3–5 minutes of buffer warmup after restart.

3. **Relay auth**: All 14 venue relay endpoints (`/api/<venue>/...`) require `x-relay-secret` header matching `RELAY_SECRET`.

4. **Geo-blocked venues**: Binance and Bybit are geo-blocked in some regions; they automatically fall back to CoinGecko-anchored synthetic depth marked `transport: "synthetic"`.

5. **PostgreSQL**: Used only for alert rules and history. All other data (TSLE buffer, tape, depth, PoLi) is in-memory.

6. **Production build**: `npm run build` compiles TypeScript and bundles the Vite frontend to `dist/public`. The Express server serves the static bundle.
