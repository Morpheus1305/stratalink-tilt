# TILT Terminal — Source Code Export
## StrataLink Labs · Institutional Liquidity Truth Terminal

Generated: $(date -u +"%Y-%m-%d %H:%M UTC")

---

## Contents

```
client/src/
├── pages/platform/
│   ├── tilt-terminal.tsx          ← Main TILT Terminal page component (~683 lines)
│   └── tilt-terminal.css          ← Scoped TILT styles (tilt-* prefix, ~772 lines)
├── components/
│   ├── dashboard-header.tsx       ← Top nav/header bar (auth, settings, help)
│   ├── platform-tabs.tsx          ← LIQUIDITY / STRATA AI / PoLi / RCL / ALERTS tab bar
│   ├── platform-footer.tsx        ← Status bar (venue count, latency, live indicator)
│   ├── export-button.tsx          ← PDF/JSON/CSV export dropdown button
│   └── ilu-token-selector.tsx     ← ILU-20 live token picker (CoinMarketCap Top 20)
├── contexts/
│   └── TokenContext.tsx           ← selectedSymbol global state (BTC/ETH/SOL/…)
└── lib/
    └── reportPdfGenerator.ts      ← jsPDF-based report generator (Token Liquidity + Cross-Venue PDFs)
```

---

## API Dependency

The terminal fetches live data from a single endpoint, polled every 5 seconds:

```
GET /api/analytics/l5f/snapshot/:symbol
```

### Response shape (`TsleAggregate`)

```ts
{
  symbol: string;
  computed_at_utc: number;
  venue_count: number;
  total_depth_10bps: number;
  total_depth_25bps: number;
  regulated_depth_share: number;    // 0–1 fraction
  offshore_depth_share: number;     // 0–1 fraction
  fragmentation_index: number;      // HHI-based, 0–1
  spread_dispersion_bps: number;
  vol_regime: "NORMAL" | "ELEVATED" | "STRESS";
  depth_decay_rate: number;
  withdrawal_velocity: number;
  spread_elasticity: number;

  // L5F factor scores (0–100 each)
  l5f_depth_quality: number;       // weight 0.30
  l5f_resilience: number;          // weight 0.20
  l5f_fragmentation: number;       // weight 0.15 (inverted HHI)
  l5f_exec_integrity: number;      // weight 0.20
  l5f_regime_stability: number;    // weight 0.15
  l5f_composite: number;           // 0–100 weighted sum

  venue_slices: VenueSlice[];
}

interface VenueSlice {
  venue_id: string;
  depth_10bps: number;
  depth_share_pct: number;
  spread_bps: number;
  stability_score: number;
  is_regulated: boolean;
  weight_class: string;
  exec_integrity_score: number;
  price_leadership_score: number;
  poli_score: number;
}
```

The backend computes this from a ring-buffer of `LISSnapshot` records across
all 14 connected venues (Binance, Coinbase, Kraken, OKX, Bybit, Bitget,
Deribit, Hyperliquid, dYdX, Uniswap, Curve, GMX, OTC, Canton).

---

## Frontend Dependencies

| Package | Purpose |
|---|---|
| `@tanstack/react-query` v5 | Data fetching / polling |
| `wouter` | Routing |
| `jspdf` | PDF generation in-browser |
| `lucide-react` | Icons |
| `shadcn/ui` | Base UI components |
| `tailwindcss` | Utility CSS |

### CSS Architecture

`tilt-terminal.css` is fully self-contained and scoped under `.tilt-root`.
All custom properties use the `--tilt-*` prefix. No Tailwind utilities are used
inside the TILT panels — the CSS file can be dropped into any project.

### Context / State

`TokenContext` exposes `selectedSymbol` (e.g. `"BTC"`) via `useToken()`.
The TILT terminal reads this to construct the API URL.

---

## L5F Score Formula

```
L5F = 0.30 × DQ + 0.20 × R + 0.15 × (100 – F) + 0.20 × EI + 0.15 × RS

where:
  DQ  = Depth Quality      (0–100)
  R   = Resilience         (0–100, needs ~3-5 min buffer to stabilise)
  F   = Fragmentation      (0–100, inverted — lower raw = better quality)
  EI  = Execution Integrity (0–100)
  RS  = Regime Stability   (0–100, needs ~3-5 min buffer to stabilise)
```

**Status bands:**
| Score | Label | Color |
|---|---|---|
| ≥ 80 | ROBUST | Green |
| 65–79 | STABLE | Teal |
| 50–64 | FRAGILE | Amber |
| < 50 | DETERIORATING | Red |

---

## PoLi Rating Bands (PDF Reports)

| Score | Rating |
|---|---|
| ≥ 90 | AAA |
| ≥ 80 | AA |
| ≥ 70 | A |
| ≥ 60 | BBB |
| ≥ 50 | BB |
| ≥ 40 | B |
| ≥ 25 | CCC |
| < 25 | D |

---

## Panel Layout

```
┌──────────────────────────────────────────────┬──────────────┐
│  PANEL 1: Liquidity Health Core              │ PANEL 4:     │
│  • L5F Score Ring (SVG, animated)            │ Stress &     │
│  • 5-factor breakdown with trend arrows      │ Regime       │
│  • Weighted composite formula display        │              │
├──────────────────────────────────────────────┼──────────────┤
│  PANEL 2: Cross-Venue Depth Map              │ PANEL 3:     │
│  • Full venue table (all 14 venues)          │ Structural   │
│  • Depth, share %, regulated flag,           │ Integrity    │
│    stability score, depth share bar          │              │
└──────────────────────────────────────────────┴──────────────┘
```

---

*StrataLink Labs Ltd · Confidential · For institutional use only*
